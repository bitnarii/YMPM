import React from "react";

function ItemGraph() {
    return ( 
        <>
        <div id="u561" className="ax_default">

<div id="u562" className="ax_default table_cell">
  <img id="u562_img" className="img " src="images/new_dailylook/u285.png" alt=""/>
  <div id="u562_text" className="text ">
    <p><span>상의</span></p>
  </div>
</div>


<div id="u563" className="ax_default table_cell">
  <img id="u563_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u563_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u564" className="ax_default table_cell">
  <img id="u564_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u564_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u565" className="ax_default table_cell">
  <img id="u565_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u565_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u566" className="ax_default table_cell">
  <img id="u566_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u566_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u567" className="ax_default table_cell">
  <img id="u567_img" className="img " src="images/new_dailylook/u290.png" alt=""/>
  <div id="u567_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u568" className="ax_default table_cell">
  <img id="u568_img" className="img " src="images/new_dailylook/u285.png" alt=""/>
  <div id="u568_text" className="text ">
    <p><span>하의</span></p>
  </div>
</div>


<div id="u569" className="ax_default table_cell">
  <img id="u569_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u569_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u570" className="ax_default table_cell">
  <img id="u570_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u570_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u571" className="ax_default table_cell">
  <img id="u571_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u571_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u572" className="ax_default table_cell">
  <img id="u572_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u572_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u573" className="ax_default table_cell">
  <img id="u573_img" className="img " src="images/new_dailylook/u290.png" alt=""/>
  <div id="u573_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u574" className="ax_default table_cell">
  <img id="u574_img" className="img " src="images/new_dailylook/u285.png" alt=""/>
  <div id="u574_text" className="text ">
    <p><span>원피스</span></p>
  </div>
</div>


<div id="u575" className="ax_default table_cell">
  <img id="u575_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u575_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u576" className="ax_default table_cell">
  <img id="u576_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u576_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u577" className="ax_default table_cell">
  <img id="u577_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u577_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u578" className="ax_default table_cell">
  <img id="u578_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u578_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u579" className="ax_default table_cell">
  <img id="u579_img" className="img " src="images/new_dailylook/u290.png" alt=""/>
  <div id="u579_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u580" className="ax_default table_cell">
  <img id="u580_img" className="img " src="images/new_dailylook/u285.png" alt=""/>
  <div id="u580_text" className="text ">
    <p><span>신발</span></p>
  </div>
</div>


<div id="u581" className="ax_default table_cell">
  <img id="u581_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u581_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u582" className="ax_default table_cell">
  <img id="u582_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u582_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u583" className="ax_default table_cell">
  <img id="u583_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u583_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u584" className="ax_default table_cell">
  <img id="u584_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u584_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u585" className="ax_default table_cell">
  <img id="u585_img" className="img " src="images/new_dailylook/u290.png" alt=""/>
  <div id="u585_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u586" className="ax_default table_cell">
  <img id="u586_img" className="img " src="images/new_dailylook/u285.png" alt=""/>
  <div id="u586_text" className="text ">
    <p><span>외투</span></p>
  </div>
</div>


<div id="u587" className="ax_default table_cell">
  <img id="u587_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u587_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u588" className="ax_default table_cell">
  <img id="u588_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u588_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u589" className="ax_default table_cell">
  <img id="u589_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u589_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u590" className="ax_default table_cell">
  <img id="u590_img" className="img " src="images/new_dailylook/u286.png" alt=""/>
  <div id="u590_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u591" className="ax_default table_cell">
  <img id="u591_img" className="img " src="images/new_dailylook/u290.png" alt=""/>
  <div id="u591_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u592" className="ax_default table_cell">
  <img id="u592_img" className="img " src="images/new_dailylook/u315.png" alt=""/>
  <div id="u592_text" className="text ">
    <p><span>패션 잡화</span></p>
  </div>
</div>


<div id="u593" className="ax_default table_cell">
  <img id="u593_img" className="img " src="images/new_dailylook/u316.png" alt=""/>
  <div id="u593_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u594" className="ax_default table_cell">
  <img id="u594_img" className="img " src="images/new_dailylook/u316.png" alt=""/>
  <div id="u594_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u595" className="ax_default table_cell">
  <img id="u595_img" className="img " src="images/new_dailylook/u316.png" alt=""/>
  <div id="u595_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u596" className="ax_default table_cell">
  <img id="u596_img" className="img " src="images/new_dailylook/u316.png" alt=""/>
  <div id="u596_text" className="text " >
    <p></p>
  </div>
</div>


<div id="u597" className="ax_default table_cell">
  <img id="u597_img" className="img " src="images/new_dailylook/u320.png" alt=""/>
  <div id="u597_text" className="text " >
    <p></p>
  </div>
</div>






</div>
        </>
     );
}

export default ItemGraph;