import React from "react";

function ClothInfo() {
    return ( 
        <>
        <div>
<div id="u607" className="ax_default box_3">
  <div id="u607_div" className=""></div>
  <div id="u607_text" className="text ">
    <p><span>Information</span></p>
  </div>
</div>

<div id="u600" className="ax_default box_1">
  <div id="u600_div" className=""></div>
  <div id="u600_text" className="text " >
    <p></p>
  </div>
</div>

<div id="u659" >
  <div id="u659_div" className=""></div>
  <div id="u659_text" >
    <p><span>브랜드</span></p>
  </div>
</div>


<div id="u660" >
  <div id="u660_div" className=""></div>
  <div id="u660_text" >
    <p><span>상품명</span></p>
  </div>
</div>

<div id="u638" className="ax_default heading_3">
  <div id="u638_div" className=""></div>
  <div id="u638_text" className="text ">
    <p><span>상의</span></p>
  </div>
</div>

<div id="u635" className="ax_default text_field">
  <div id="u635_div" className=""></div>
  <input id="u635_input" type="text" value="" className="u635_input"/>
</div>

<div id="u637" className="ax_default heading_3">
  <div id="u637_div" className=""></div>
  <div id="u637_text" className="text ">
    <p><span>/</span></p>
  </div>
</div>

<div id="u636" className="ax_default text_field">
  <div id="u636_div" className=""></div>
  <input id="u636_input" type="text" value="" className="u636_input"/>
</div>


<div id="u642" className="ax_default heading_3">
  <div id="u642_div" className=""></div>
  <div id="u642_text" className="text ">
    <p><span>하의</span></p>
  </div>
</div>

<div id="u639" className="ax_default text_field">
  <div id="u639_div" className=""></div>
  <input id="u639_input" type="text" value="" className="u639_input"/>
</div>

<div id="u641" className="ax_default heading_3">
  <div id="u641_div" className=""></div>
  <div id="u641_text" className="text ">
    <p><span>/</span></p>
  </div>
</div>

<div id="u640" className="ax_default text_field">
  <div id="u640_div" className=""></div>
  <input id="u640_input" type="text" value="" className="u640_input"/>
</div>


<div id="u646" className="ax_default heading_3">
  <div id="u646_div" className=""></div>
  <div id="u646_text" className="text ">
    <p><span>원피스</span></p>
  </div>
</div>

<div id="u643" className="ax_default text_field">
  <div id="u643_div" className=""></div>
  <input id="u643_input" type="text" value="" className="u643_input"/>
</div>

<div id="u645" className="ax_default heading_3">
  <div id="u645_div" className=""></div>
  <div id="u645_text" className="text ">
    <p><span>/</span></p>
  </div>
</div>

<div id="u644" className="ax_default text_field">
  <div id="u644_div" className=""></div>
  <input id="u644_input" type="text" value="" className="u644_input"/>
</div>





<div id="u650" className="ax_default heading_3">
  <div id="u650_div" className=""></div>
  <div id="u650_text" className="text ">
    <p><span>아우터</span></p>
  </div>
</div>

<div id="u647" className="ax_default text_field">
  <div id="u647_div" className=""></div>
  <input id="u647_input" type="text" value="" className="u647_input"/>
</div>

<div id="u649" className="ax_default heading_3">
  <div id="u649_div" className=""></div>
  <div id="u649_text" className="text ">
    <p><span>/</span></p>
  </div>
</div>

<div id="u648" className="ax_default text_field">
  <div id="u648_div" className=""></div>
  <input id="u648_input" type="text" value="" className="u648_input"/>
</div>


<div id="u654" className="ax_default heading_3">
  <div id="u654_div" className=""></div>
  <div id="u654_text" className="text ">
    <p><span>신발</span></p>
  </div>
</div>

<div id="u651" className="ax_default text_field">
  <div id="u651_div" className=""></div>
  <input id="u651_input" type="text" value="" className="u651_input"/>
</div>

<div id="u653" className="ax_default heading_3">
  <div id="u653_div" className=""></div>
  <div id="u653_text" className="text ">
    <p><span>/</span></p>
  </div>
</div>

<div id="u652" className="ax_default text_field">
  <div id="u652_div" className=""></div>
  <input id="u652_input" type="text" value="" className="u652_input"/>
</div>


<div id="u658" className="ax_default heading_3">
  <div id="u658_div" className=""></div>
  <div id="u658_text" className="text ">
    <p><span>패션 잡화</span></p>
  </div>
</div>

<div id="u655" className="ax_default text_field">
  <div id="u655_div" className=""></div>
  <input id="u655_input" type="text" value="" className="u655_input"/>
</div>

<div id="u657" className="ax_default heading_3">
  <div id="u657_div" className=""></div>
  <div id="u657_text" className="text ">
    <p><span>/</span></p>
  </div>
</div>

<div id="u656" className="ax_default text_field">
  <div id="u656_div" className=""></div>
  <input id="u656_input" type="text" value="" className="u656_input"/>
</div>
</div>
        </>
     );
}

export default ClothInfo;