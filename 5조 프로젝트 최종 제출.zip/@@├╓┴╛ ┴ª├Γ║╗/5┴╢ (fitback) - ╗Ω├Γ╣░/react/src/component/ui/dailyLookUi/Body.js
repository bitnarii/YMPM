import React from "react";

function Body() {
    return ( 
        <>
          <div>
  <div id="u602" className="ax_default box_3">
    <div id="u602_div" className=""></div>
    <div id="u602_text" className="text " >
      
    </div>
  </div>
<div id="u612" className="ax_default" data-left="1" data-top="131" data-width="400" data-height="710">

  
  <div id="u613" className="ax_default box_3">
    <div id="u613_div" className=""></div>
    <div id="u613_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u614" className="ax_default image">
    <img id="u614_img" className="img " src="images/new_dailylook/u337.png" alt=""/>
    <div id="u614_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u615" className="ax_default placeholder">
    <img id="u615_img" className="img " src="images/new_dailylook/u338.svg" alt=""/>
    <div id="u615_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u616" className="ax_default placeholder">
    <img id="u616_img" className="img " src="images/new_dailylook/u339.svg" alt=""/>
    <div id="u616_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u617" className="ax_default placeholder">
    <img id="u617_img" className="img " src="images/new_dailylook/u340.svg" alt=""/>
    <div id="u617_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u618" className="ax_default placeholder">
    <img id="u618_img" className="img " src="images/new_dailylook/u341.svg" alt=""/>
    <div id="u618_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u619" className="ax_default placeholder">
    <img id="u619_img" className="img " src="images/new_dailylook/u342.svg" alt=""/>
    <div id="u619_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u620" className="ax_default placeholder">
    <img id="u620_img" className="img " src="images/new_dailylook/u343.svg" alt=""/>
    <div id="u620_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u621" className="ax_default placeholder">
    <img id="u621_img" className="img " src="images/new_dailylook/u344.svg" alt=""/>
    <div id="u621_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u622" className="ax_default placeholder">
    <img id="u622_img" className="img " src="images/new_dailylook/u345.svg" alt=""/>
    <div id="u622_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u623" className="ax_default placeholder">
    <img id="u623_img" className="img " src="images/new_dailylook/u346.svg" alt=""/>
    <div id="u623_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u624" className="ax_default placeholder">
    <img id="u624_img" className="img " src="images/new_dailylook/u347.svg" alt=""/>
    <div id="u624_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u625" className="ax_default placeholder">
    <img id="u625_img" className="img " src="images/new_dailylook/u348.svg" alt=""/>
    <div id="u625_text" className="text " >
      <p></p>
    </div>
  </div>


  <div id="u626" className="ax_default placeholder">
    <img id="u626_img" className="img " src="images/new_dailylook/u349.svg" alt=""/>
    <div id="u626_text" className="text " >
      <p></p>
    </div>
  </div>
</div>
</div>
        </>
     );
}

export default Body;