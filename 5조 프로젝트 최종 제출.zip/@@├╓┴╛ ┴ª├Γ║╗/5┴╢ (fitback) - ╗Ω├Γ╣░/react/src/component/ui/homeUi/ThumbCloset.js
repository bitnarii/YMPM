import React from "react";

function ThumbCloset() {
    return ( 
        <div>
<div id="u234" className="ax_default box_2">
  <div id="u234_div" className=""></div>
  <div id="u234_text" className="text ">
    <p><span>대표 옷장</span></p>
  </div>
</div>

<div id="u231" className="ax_default image">
  <img id="u231_img" className="img " src="images/home/u231.png" alt=""/>
  <div id="u231_text" className="text " >
    <p></p>
  </div>
</div>

<div id="u233" className="ax_default button">
  <img id="u233_img" className="img " src="images/home/u233.svg" alt=""/>
  <div id="u233_text" className="text ">
    <p><span>대표 옷장</span></p><p><span>교&nbsp; &nbsp; &nbsp; &nbsp; 체</span></p>
  </div>
</div>

<div id="u232" className="ax_default box_2">
  <div id="u232_div" className=""></div>
  <div id="u232_text" className="text ">
    <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 용</span></p>
  </div>
</div>
</div>
     );
}

export default ThumbCloset;