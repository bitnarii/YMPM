import React from "react";

function ThumbLook() {
    return ( 
        <div>
        <div id="u226" className="ax_default box_2">
          <div id="u226_div" className=""></div>
          <div id="u226_text" className="text ">
            <p><span>대표 룩</span></p>
          </div>
        </div>
        
        <div id="u240" className="ax_default placeholder">
          <img id="u240_img" className="img " src="images/home/u240.svg" alt=""/>
          <div id="u240_text" className="text " >
            <p></p>
          </div>
        </div>
        
        <div id="u238" className="ax_default box_2">
          <div id="u238_div" className=""></div>
          <div id="u238_text" className="text " >
            <p></p>
          </div>
        </div>
        
        <div id="u257" className="ax_default heading_3">
          <div id="u257_div" className=""></div>
          <div id="u257_text" className="text ">
            <p><span>내 정보</span></p>
          </div>
        </div>
        
        <div id="u247" className="ax_default heading_3">
          <div id="u247_div" className=""></div>
          <div id="u247_text" className="text ">
            <p><span>성별</span></p>
          </div>
        </div>
        
        <div id="u256" className="ax_default box_1">
          <div id="u256_div" className=""></div>
          <div id="u256_text" className="text " >
            <p></p>
          </div>
        </div>
        
        <div id="u248" className="ax_default heading_3">
          <div id="u248_div" className=""></div>
          <div id="u248_text" className="text ">
            <p><span>키</span></p>
          </div>
        </div>
        
        <div id="u255" className="ax_default box_1">
          <div id="u255_div" className=""></div>
          <div id="u255_text" className="text " >
            <p></p>
          </div>
        </div>
        
        <div id="u249" className="ax_default heading_3">
          <div id="u249_div" className=""></div>
          <div id="u249_text" className="text ">
            <p><span>사이즈</span></p>
          </div>
        </div>
        
        
        <div id="u250" className="ax_default box_1">
          <div id="u250_div" className=""></div>
          <div id="u250_text" className="text " >
            <p></p>
          </div>
        </div>
        
        
        <div id="u251" className="ax_default heading_3">
          <div id="u251_div" className=""></div>
          <div id="u251_text" className="text ">
            <p><span>신발 사이즈</span></p>
          </div>
        </div>
        
        
        <div id="u252" className="ax_default box_1">
          <div id="u252_div" className=""></div>
          <div id="u252_text" className="text " >
            <p></p>
          </div>
        </div>
        
        
        <div id="u253" className="ax_default heading_3">
          <div id="u253_div" className=""></div>
          <div id="u253_text" className="text ">
            <p><span>기타 특징</span></p>
          </div>
        </div>
        
        
        <div id="u254" className="ax_default box_1">
          <div id="u254_div" className=""></div>
          <div id="u254_text" className="text " >
            <p></p>
          </div>
        </div>
        
        
        
        
        <div id="u258" className="ax_default button">
          <img id="u258_img" className="img " src="images/home/u258.svg" alt=""/>
          <div id="u258_text" className="text ">
            <p><span>정보 수정</span></p>
          </div>
        </div>
        
        
        <div id="u259" className="ax_default button">
          <img id="u259_img" className="img " src="images/home/u259.svg" alt=""/>
          <div id="u259_text" className="text ">
            <p><span>대표 룩 수정</span></p>
          </div>
        </div>
        
        </div>
     );
}

export default ThumbLook;