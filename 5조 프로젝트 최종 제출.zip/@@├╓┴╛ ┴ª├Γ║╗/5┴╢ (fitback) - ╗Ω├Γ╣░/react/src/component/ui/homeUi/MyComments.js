import React from "react";

function MyComments() {
    return ( 
        <>
        <div>
    <div id="u223" className="ax_default box_2">
    <div id="u223_div" className=""></div>
    <div id="u223_text" className="text " >
        <p></p>
    </div>
    </div>

    <div id="u237" className="ax_default box_2">
    <div id="u237_div" className=""></div>
    <div id="u237_text" className="text ">
        <p><span>내가 쓴 댓글 모음</span></p>
    </div>
    </div>

<div id="u272" className="ax_default text_field">
  <div id="u272_div" className=""></div>
  <input id="u272_input" type="text" value="" className="u272_input"/>
</div>

    <div id="u276" className="ax_default heading_3">
    <div id="u276_div" className=""></div>
    <div id="u276_text" className="text ">
        <p><span>점 / fitback:</span></p>
    </div>
    </div>


    <div id="u277" className="ax_default text_field">
    <div id="u277_div" className=""></div>
    <input id="u277_input" type="text" value="" className="u277_input"/>
    </div>

<div id="u273" className="ax_default text_field">
  <div id="u273_div" className=""></div>
  <input id="u273_input" type="text" value="" className="u273_input"/>
</div>

    <div id="u278" className="ax_default heading_3">
    <div id="u278_div" className=""></div>
    <div id="u278_text" className="text ">
        <p><span>점 / fitback:</span></p>
    </div>
    </div>


    <div id="u279" className="ax_default text_field">
    <div id="u279_div" className=""></div>
    <input id="u279_input" type="text" value="" className="u279_input"/>
    </div>

<div id="u274" className="ax_default text_field">
  <div id="u274_div" className=""></div>
  <input id="u274_input" type="text" value="" className="u274_input"/>
</div>

    <div id="u280" className="ax_default heading_3">
    <div id="u280_div" className=""></div>
    <div id="u280_text" className="text ">
        <p><span>점 / fitback:</span></p>
    </div>
    </div>


    <div id="u281" className="ax_default text_field">
    <div id="u281_div" className=""></div>
    <input id="u281_input" type="text" value="" className="u281_input"/>
    </div>

<div id="u275" className="ax_default text_field">
  <div id="u275_div" className=""></div>
  <input id="u275_input" type="text" value="" className="u275_input"/>
</div>

    <div id="u282" className="ax_default heading_3">
    <div id="u282_div" className=""></div>
    <div id="u282_text" className="text ">
        <p><span>점 / fitback:</span></p>
    </div>
    </div>


    <div id="u283" className="ax_default text_field">
    <div id="u283_div" className=""></div>
    <input id="u283_input" type="text" value="" className="u283_input"/>
    </div>
    

    <div id="u239" className="ax_default button">
    <div id="u239_div" className=""></div>
    <div id="u239_text" className="text ">
        <p><span>댓글 더보기</span></p>
    </div>
    </div>
</div>
        </>
     );
}

export default MyComments;