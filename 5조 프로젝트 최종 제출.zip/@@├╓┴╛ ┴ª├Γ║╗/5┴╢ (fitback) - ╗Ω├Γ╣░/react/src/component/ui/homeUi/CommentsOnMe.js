import React from "react";

function CommentsOnMe() {
    return ( 
        <>
        <div>

<div id="u235" className="ax_default box_2">
  <div id="u235_div" className=""></div>
  <div id="u235_text" className="text ">
    <p><span>내게 달린 댓글 모음</span></p>
  </div>
</div>

<div id="u224" className="ax_default box_2">
  <div id="u224_div" className=""></div>
  <div id="u224_text" className="text " >
    <p></p>
  </div>
</div>

<div id="u260" className="ax_default text_field">
  <div id="u260_div" className=""></div>
  <input id="u260_input" type="text" value="" className="u260_input"/>
</div>

<div id="u264" className="ax_default heading_3">
  <div id="u264_div" className=""></div>
  <div id="u264_text" className="text ">
    <p><span>점 / fitback:</span></p>
  </div>
</div>


<div id="u265" className="ax_default text_field">
  <div id="u265_div" className=""></div>
  <input id="u265_input" type="text" />
</div>

<div id="u261" className="ax_default text_field">
  <div id="u261_div" className=""></div>
  <input id="u261_input" type="text" value="" className="u261_input"/>
</div>

<div id="u266" className="ax_default heading_3">
  <div id="u266_div" className=""></div>
  <div id="u266_text" className="text ">
    <p><span>점 / fitback:</span></p>
  </div>
</div>


<div id="u267" className="ax_default text_field">
  <div id="u267_div" className=""></div>
  <input id="u267_input" type="text" value="" className="u267_input"/>
</div>

<div id="u262" className="ax_default text_field">
  <div id="u262_div" className=""></div>
  <input id="u262_input" type="text" value="" className="u262_input"/>
</div>

<div id="u268" className="ax_default heading_3">
  <div id="u268_div" className=""></div>
  <div id="u268_text" className="text ">
    <p><span>점 / fitback:</span></p>
  </div>
</div>


<div id="u269" className="ax_default text_field">
  <div id="u269_div" className=""></div>
  <input id="u269_input" type="text" value="" className="u269_input"/>
</div>

<div id="u263" className="ax_default text_field">
  <div id="u263_div" className=""></div>
  <input id="u263_input" type="text" value="" className="u263_input"/>
</div>

<div id="u270" className="ax_default heading_3">
  <div id="u270_div" className=""></div>
  <div id="u270_text" className="text ">
    <p><span>점 / fitback:</span></p>
  </div>
</div>


<div id="u271" className="ax_default text_field">
  <div id="u271_div" className=""></div>
  <input id="u271_input" type="text" value="" className="u271_input"/>
</div>

<div id="u228" className="ax_default button">
  <div id="u228_div" className=""></div>
  <div id="u228_text" className="text ">
    <p><span>댓글 더보기</span></p>
  </div>
</div>

</div>
        </>
     );
}

export default CommentsOnMe;