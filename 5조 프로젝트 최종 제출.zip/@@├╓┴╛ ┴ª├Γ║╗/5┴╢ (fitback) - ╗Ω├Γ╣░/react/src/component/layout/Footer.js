import React from 'react';

function Footer() {
    return ( 
    <div id="base" class="">
      
      <img id="u1013_img" src="images/footer/u1013.svg"/>
        


      <div id="u1015" class="ax_default paragraph">
        <div id="u1015_text" class="text ">
          <span>FitBack</span>
        </div>
      </div>

      <div id="u1016" class="ax_default paragraph">
        <div id="u1016_text" class="text ">
          <span>일일 코디 관리 및 피드백 서비스</span>
        </div>
      </div>

      {/* <div id="u1017" class="ax_default paragraph">
        <div id="u1017_text" class="text ">
          <span>About Us</span>
        </div>
      </div>

      <div id="u1014" class="ax_default paragraph">
        <div id="u1014_text" class="text ">
          <span >&nbsp;YMPM<br></br></span><span >
            권빛나리(sakaki9157@gmail.com)</span><span >
            곽다은(bbibibbibi22@gmail.com)<br></br></span><span >
            신효원(projectann215@gmail.com)</span>
        </div>
      </div> */}

    </div>
     );
}

export default Footer;