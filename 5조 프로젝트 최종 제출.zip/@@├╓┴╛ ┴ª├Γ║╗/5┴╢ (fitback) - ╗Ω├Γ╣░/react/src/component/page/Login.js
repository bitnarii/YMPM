import React from 'react';

function Login() {
    return ( 
      <div id="base" class="">

        <div id="u813" class="ax_default box_2">
          <div id="u813_div" class=""></div>       
        </div>
  
        <div id="u814" class="ax_default text_field">
          <div id="u814_div" class=""></div>
          <input id="u814_input" type="text" class="u814_input"/>
        </div>
  
        <div id="u815" class="ax_default text_field">
          <div id="u815_div" class=""></div>
          <input id="u815_input" type="password" class="u815_input"/>
        </div>
  
        <div id="u816" class="ax_default primary_button">
          <div id="u816_div" class=""></div>
          <div id="u816_text" class="text ">
            <p><span>로그인</span></p>
          </div>
        </div>
  
        <div id="u817" class="ax_default heading_1">
          <div id="u817_div" class=""></div>
          <div id="u817_text" class="text ">
            <p><span>Login</span></p>
          </div>
        </div>
  
        <div id="u818" class="ax_default link_button1">
          <div id="u818_div" class=""></div>
          <div id="u818_text" class="text ">
            <p><span>회원가입</span></p>
          </div>
        </div>
      </div>
     );
}

export default Login;