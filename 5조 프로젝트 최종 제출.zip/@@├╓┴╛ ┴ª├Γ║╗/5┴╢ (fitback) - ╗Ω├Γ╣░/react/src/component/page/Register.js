import React from 'react';

function Register() {
    return (  
      <div id="base" class="">

        {/* Unnamed (Rectangle) */}
        <div id="u819" class="ax_default heading_3">
          <div id="u819_div" class=""></div>
          <div id="u819_text" class="text ">
            <p><span>아이디</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u820" class="ax_default heading_2">
          <div id="u820_div" class=""></div>
          <div id="u820_text" class="text ">
            <p><span>회원가입</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u821" class="ax_default heading_3">
          <div id="u821_div" class=""></div>
          <div id="u821_text" class="text ">
            <p><span>비밀번호</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u822" class="ax_default heading_3">
          <div id="u822_div" class=""></div>
          <div id="u822_text" class="text ">
            <p><span>이름</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u823" class="ax_default heading_3">
          <div id="u823_div" class=""></div>
          <div id="u823_text" class="text ">
            <p><span>성별</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u824" class="ax_default heading_3">
          <div id="u824_div" class=""></div>
          <div id="u824_text" class="text ">
            <p><span>전화번호</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u825" class="ax_default heading_3">
          <div id="u825_div" class=""></div>
          <div id="u825_text" class="text ">
            <p><span>이메일주소</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u826" class="ax_default heading_3">
          <div id="u826_div" class=""></div>
          <div id="u826_text" class="text ">
            <p><span>생년월일</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u827" class="ax_default heading_3">
          <div id="u827_div" class=""></div>
          <div id="u827_text" class="text ">
            <p><span>비밀번호 확인</span></p><p><span></span></p>
          </div>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u828" class="ax_default text_field">
          <div id="u828_div" class=""></div>
          <input id="u828_input" type="text" value="" class="u828_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u829" class="ax_default text_field">
          <div id="u829_div" class=""></div>
          <input id="u829_input" type="text" value="" class="u829_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u830" class="ax_default text_field">
          <div id="u830_div" class=""></div>
          <input id="u830_input" type="text" value="" class="u830_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u831" class="ax_default text_field">
          <div id="u831_div" class=""></div>
          <input id="u831_input" type="text" value="" class="u831_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u832" class="ax_default text_field">
          <div id="u832_div" class=""></div>
          <input id="u832_input" type="text" value="" class="u832_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u833" class="ax_default text_field">
          <div id="u833_div" class=""></div>
          <input id="u833_input" type="text" value="" class="u833_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u834" class="ax_default text_field">
          <div id="u834_div" class=""></div>
          <input id="u834_input" type="text" value="" class="u834_input"/>
        </div>

        {/* Unnamed (Shape) */}
        <div id="u835" class="ax_default primary_button">
          <img id="u835_img" class="img " src="images/register/u835.svg"/>
          <div id="u835_text" class="text ">
            <p><span>아이디 중복확인</span></p>
          </div>
        </div>

        {/* Unnamed (Shape) */}
        <div id="u836" class="ax_default primary_button">
          <img id="u836_img" class="img " src="images/register/u836.svg"/>
          <div id="u836_text" class="text ">
            <p><span>이메일 중복확인</span></p>
          </div>
        </div>

        {/* Unnamed (Droplist) */}
        <div id="u837" class="ax_default droplist">
          <div id="u837_div" class=""></div>
          <select id="u837_input" class="u837_input">
          </select>
        </div>

        {/* Unnamed (Droplist) */}
        <div id="u838" class="ax_default droplist">
          <div id="u838_div" class=""></div>
          <select id="u838_input" class="u838_input">
          </select>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u839" class="ax_default heading_3">
          <div id="u839_div" class=""></div>
          <div id="u839_text" class="text ">
            <p><span>년</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u840" class="ax_default heading_3">
          <div id="u840_div" class=""></div>
          <div id="u840_text" class="text ">
            <p><span>일</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u841" class="ax_default heading_3">
          <div id="u841_div" class=""></div>
          <div id="u841_text" class="text ">
            <p><span>월</span></p>
          </div>
        </div>

        {/* Unnamed (Droplist) */}
        <div id="u842" class="ax_default droplist">
          <div id="u842_div" class=""></div>
          <select id="u842_input" class="u842_input">
          </select>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u843" class="ax_default primary_button">
          <div id="u843_div" class=""></div>
          <div id="u843_text" class="text ">
            <p><span>회원가입</span></p>
          </div>
        </div>
      </div>
   );
}

export default Register;