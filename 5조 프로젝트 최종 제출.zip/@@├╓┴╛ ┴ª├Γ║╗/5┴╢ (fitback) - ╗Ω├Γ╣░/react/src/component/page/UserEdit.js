import React from 'react';

function UserEdit() {
    return ( 
      <div id="base" class="">

        {/* Unnamed (Rectangle) */}
        <div id="u844" class="ax_default heading_2">
          <div id="u844_div" class=""></div>
          <div id="u844_text" class="text ">
            <p><span>회원정보수정</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u845" class="ax_default heading_3">
          <div id="u845_div" class=""></div>
          <div id="u845_text" class="text ">
            <p><span>아이디</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u846" class="ax_default heading_3">
          <div id="u846_div" class=""></div>
          <div id="u846_text" class="text ">
            <p><span>비밀번호</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u847" class="ax_default heading_3">
          <div id="u847_div" class=""></div>
          <div id="u847_text" class="text ">
            <p><span>이름</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u848" class="ax_default heading_3">
          <div id="u848_div" class=""></div>
          <div id="u848_text" class="text ">
            <p><span>성별</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u849" class="ax_default heading_3">
          <div id="u849_div" class=""></div>
          <div id="u849_text" class="text ">
            <p><span>전화번호</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u850" class="ax_default heading_3">
          <div id="u850_div" class=""></div>
          <div id="u850_text" class="text ">
            <p><span>이메일주소</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u851" class="ax_default heading_3">
          <div id="u851_div" class=""></div>
          <div id="u851_text" class="text ">
            <p><span>생년월일</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u852" class="ax_default heading_3">
          <div id="u852_div" class=""></div>
          <div id="u852_text" class="text ">
            <p><span>비밀번호 확인</span></p><p><span></span></p>
          </div>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u853" class="ax_default text_field">
          <div id="u853_div" class=""></div>
          <input id="u853_input" type="text" value="abcedfg" class="u853_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u854" class="ax_default text_field">
          <div id="u854_div" class=""></div>
          <input id="u854_input" type="text" value="" class="u854_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u855" class="ax_default text_field">
          <div id="u855_div" class=""></div>
          <input id="u855_input" type="text" value="" class="u855_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u856" class="ax_default text_field">
          <div id="u856_div" class=""></div>
          <input id="u856_input" type="text" value="" class="u856_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u857" class="ax_default text_field">
          <div id="u857_div" class=""></div>
          <input id="u857_input" type="text" value="" class="u857_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u858" class="ax_default text_field">
          <div id="u858_div" class=""></div>
          <input id="u858_input" type="text" value="" class="u858_input"/>
        </div>

        {/* Unnamed (Text Field) */}
        <div id="u859" class="ax_default text_field">
          <div id="u859_div" class=""></div>
          <input id="u859_input" type="text" value="" class="u859_input"/>
        </div>

        {/* Unnamed (Shape) */}
        <div id="u860" class="ax_default primary_button">
          <img id="u860_img" class="img " src="images/register/u836.svg"/>
          <div id="u860_text" class="text ">
            <p><span>이메일 중복확인</span></p>
          </div>
        </div>

        {/* Unnamed (Droplist) */}
        <div id="u861" class="ax_default droplist">
          <div id="u861_div" class=""></div>
          <select id="u861_input" class="u861_input">
          </select>
        </div>

        {/* Unnamed (Droplist) */}
        <div id="u862" class="ax_default droplist">
          <div id="u862_div" class=""></div>
          <select id="u862_input" class="u862_input">
          </select>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u863" class="ax_default heading_3">
          <div id="u863_div" class=""></div>
          <div id="u863_text" class="text ">
            <p><span>년</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u864" class="ax_default heading_3">
          <div id="u864_div" class=""></div>
          <div id="u864_text" class="text ">
            <p><span>일</span></p>
          </div>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u865" class="ax_default heading_3">
          <div id="u865_div" class=""></div>
          <div id="u865_text" class="text ">
            <p><span>월</span></p>
          </div>
        </div>

        {/* Unnamed (Droplist) */}
        <div id="u866" class="ax_default droplist">
          <div id="u866_div" class=""></div>
          <select id="u866_input" class="u866_input">
          </select>
        </div>

        {/* Unnamed (Rectangle) */}
        <div id="u867" class="ax_default primary_button">
          <div id="u867_div" class=""></div>
          <div id="u867_text" class="text ">
            <p><span>정보수정</span></p>
          </div>
        </div>
      </div>
     );
}

export default UserEdit;