package com.fitback.personal.common;

import org.springframework.stereotype.Component;
import java.util.Hashtable;



@Component
public class MessageVO extends Hashtable {

}
