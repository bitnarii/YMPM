package com.fitback.personal.bookmark.dto;

public class BookmarkDto {
}
